(* ::Package:: *)

(************************ 0. Info and copyright ***********************)


PGC027`$Version={"0.2.7",{2019,6,20}}


(* PGC, Poincare Gauge Cosmology *)

(* Copyright (C) 2018-2020 Hongchao Zhang *)

(* Dalian University of Technology & Penn State University *)

(* This program is based on the xAct series *)

(* Version 0.2.7: Ghost-free, based on v0.2.6 *)


(************************ 1. Begin package ***********************)


BeginPackage["PGC027`",{"xAct`xCore`","xAct`xPerm`","xAct`xTensor`","xAct`xCoba`","xAct`xPert`"}]


(* Parallelization setting up *)
ParallelNeeds["xAct`xCore`"];
ParallelNeeds["xAct`xPerm`"];
ParallelNeeds["xAct`xTensor`"];
ParallelNeeds["xAct`xCoba`"];
ParallelNeeds["xAct`xPert`"];


PGC027`$barslength=60;
PGC027`bars=StringJoin[Table["-",{PGC027`$barslength}]];


Print[PGC027`bars];
Print[PGC027`bars];
Print["Package PGC`  version ",PGC027`$Version[[1]],", ",PGC027`$Version[[2]]];
Print["PGC, Poincare Gauge Cosmology"];
Print["Copyright (C) 2018-2020 Hongchao Zhang"];
Print["Dalian University of Technology & Penn State University"];
Print["This program is based on the xAct series"];
Print["Version 0.2.7: Ghost-free, based on v0.2.6"];
Print[PGC027`bars];


(*usage*)


(*Begin["`Private`"]*)


(************************ 2. General Statements ***********************)


(*Block[{Print},
<<xAct`xTensor`;
ParallelNeeds["xAct`xTensor`"];
(*Needs["xAct`xPrint`"]*)
<<xAct`xCoba`;
<<xAct`xPert`;
];*)


$DefInfoQ=False;
$CVVerbose=False;
$PrePrint=ScreenDollarIndices;


(* Adding the working directory *)
$PackageDirectory=ParentDirectory[DirectoryName[FindFile["PGC027`"]]];
If[!ContainsAny[$Path,{$PackageDirectory}],PrependTo[$Path,$PackageDirectory]];
Print["The current working directory is: ",$PackageDirectory];
Print[PGC027`bars];


(* my options: Torsion or Contorsion *)
$WhichVar=1;
(* Pre evaluating cdcdTorsionCD or not: 1 is yes *)
$PreEvaluatecdcdTorsionCD=1;


(* Define a manifold M *)
DefManifold[M,4,{\[Mu],\[Nu],\[Sigma],\[Tau],\[Theta],\[Upsilon],\[Xi],\[Zeta],\[Beta],\[Gamma]},PrintAs->"\!\(\*SuperscriptBox[\(M\), \(4\)]\)"];


(* Define a metric g and its perturbation *)
DefMetric[-1,metric[-\[Mu],-\[Nu]],cd,SymbolOfCovD->{";","D"},WeightedWithBasis->AIndex,PrintAs->"g"];
DefMetricPerturbation[metric,metpert,\[Epsilon]];
PrintAs[metpert]^="\[Delta]g";


Unprotect[IndexForm];
IndexForm[LI[x_]]:=ColorString[ToString[x],RGBColor[0,0,1]];
Protect[IndexForm];


(* Define a metric-affine connection compatible with the general covariant derivative CD and metric g *)
DefCovD[CD[-\[Mu]],Torsion->True,SymbolOfCovD->{"|","\[Del]"},FromMetric->metric];


(*Define the perturbations of metric-affine connection \[CapitalGamma], torsion T, and contorsion K respectively *)
DefTensorPerturbation[PertConnection[LI[order],\[Sigma],-\[Mu],-\[Nu]],ChristoffelCD[\[Sigma],-\[Mu],-\[Nu]],M];
PrintAs[PertConnection]^="\[Delta]\[CapitalGamma]";
DefTensorPerturbation[PertTorsion[LI[order],\[Sigma],-\[Mu],-\[Nu]],TorsionCD[\[Sigma],-\[Mu],-\[Nu]],M];
PrintAs[PertTorsion]^="\[Delta]T";
DefTensor[Contorsion[\[Sigma],-\[Mu],-\[Nu]],M,PrintAs->"K"];
DefTensorPerturbation[PertContorsion[LI[order],\[Sigma],-\[Mu],-\[Nu]],Contorsion[\[Sigma],-\[Mu],-\[Nu]],M];
PrintAs[PertContorsion]^="\[Delta]K";


(* Rules among \[CapitalGamma], T and K *)
rule\[CapitalGamma]=ChristoffelCD[\[Sigma]_,\[Mu]_,\[Nu]_]->Christoffelcd[\[Sigma],\[Mu],\[Nu]]+Contorsion[\[Sigma],\[Mu],\[Nu]];
ruleK=Contorsion[\[Sigma]_,\[Mu]_,\[Nu]_]->1/2 (TorsionCD[\[Sigma],\[Mu],\[Nu]]+TorsionCD[\[Mu],\[Sigma],\[Nu]]+TorsionCD[\[Nu],\[Sigma],\[Mu]]);
(*rule=Which[$WhichVar==1,rule\[CapitalGamma]/.ruleK,$WhichVar==2,rule\[CapitalGamma]];*)


metorder=metpert[LI[order_],__]:>0/;order>1;


Clear[\[Alpha],a1,a2,a3,b1,b2,b3,b4,b5,b6];
Clear[c1];
DefConstantSymbol[\[Alpha]];
DefConstantSymbol[{a1,a2,a3}];
DefConstantSymbol[{b1,b2,b3,b4,b5,b6}];
DefConstantSymbol[c1];
DefScalarFunction[a];
DefScalarFunction[h];
DefScalarFunction[f];
DefScalarFunction[\[Phi]];
DefScalarFunction[B];
DefScalarFunction[\[Psi]];
DefScalarFunction[\[CapitalEpsilon]];
DefScalarFunction[\[Phi]2];
DefScalarFunction[B2];
DefScalarFunction[\[Psi]2];
DefScalarFunction[\[CapitalEpsilon]2];
DefScalarFunction[v];
DefScalarFunction[v2];
DefScalarFunction[\[CapitalXi]];
DefScalarFunction[\[CapitalTheta]];
DefScalarFunction[\[CapitalPhi]];
DefScalarFunction[\[CapitalPsi]];
DefScalarFunction[\[CapitalXi]2];
DefScalarFunction[\[CapitalTheta]2];
DefScalarFunction[\[CapitalPhi]2];
DefScalarFunction[\[CapitalPsi]2];
DefScalarFunction[\[Rho],PrintAs->"\!\(\*OverscriptBox[\(\[Rho]\), \(_\)]\)"];
DefScalarFunction[\[Rho]m,PrintAs->"\!\(\*SubscriptBox[OverscriptBox[\(\[Rho]\), \(_\)], \(m\)]\)"];
DefScalarFunction[\[Rho]r,PrintAs->"\!\(\*SubscriptBox[OverscriptBox[\(\[Rho]\), \(_\)], \(r\)]\)"];
DefScalarFunction[p,PrintAs->"\!\(\*OverscriptBox[\(p\), \(_\)]\)"];
DefConstantSymbol[w];
DefScalarFunction[H];
DefConstantSymbol[kappa,PrintAs->"\[Kappa]"];


(* Define a chart *)
DefChart[chart,M,{0,1,2,3},{t[],x[],y[],z[]},ChartColor->RGBColor[1,0,0]]


(* the background values of metric on this chart, where \[Tau] denotes the cosmic time *)
metricbg={
 {-1, 0, 0, 0},
 {0, a[t[]]^2, 0, 0},
 {0, 0, a[t[]]^2, 0},
 {0, 0, 0, a[t[]]^2}
};
(* Write the values into the background metric *)
AllComponentValues[Perturbation[metric[-\[Mu],-\[Nu]],0]//ToBasis[chart],metricbg];
MetricCompute[metric,chart,All,CVSimplify->Simplify];


metricP1=a[t[]]^2 {{-(2/a[t[]]^2) \[Phi][t[],x[],y[],z[]],2/a[t[]] PDchart[{1,-chart}][B[t[],x[],y[],z[]]],2/a[t[]] PDchart[{2,-chart}][B[t[],x[],y[],z[]]],2/a[t[]] PDchart[{3,-chart}][B[t[],x[],y[],z[]]]},{2/a[t[]] PDchart[{1,-chart}][B[t[],x[],y[],z[]]],-2 \[Psi][t[],x[],y[],z[]]+2 PDchart[{1,-chart}][PDchart[{1,-chart}][\[CapitalEpsilon][t[],x[],y[],z[]]]],2 PDchart[{1,-chart}][PDchart[{2,-chart}][\[CapitalEpsilon][t[],x[],y[],z[]]]],2 PDchart[{1,-chart}][PDchart[{3,-chart}][\[CapitalEpsilon][t[],x[],y[],z[]]]]},{2/a[t[]] PDchart[{2,-chart}][B[t[],x[],y[],z[]]],2 PDchart[{2,-chart}][PDchart[{1,-chart}][\[CapitalEpsilon][t[],x[],y[],z[]]]],-2 \[Psi][t[],x[],y[],z[]]+2 PDchart[{2,-chart}][PDchart[{2,-chart}][\[CapitalEpsilon][t[],x[],y[],z[]]]],2 PDchart[{2,-chart}][PDchart[{3,-chart}][\[CapitalEpsilon][t[],x[],y[],z[]]]]},{2/a[t[]] PDchart[{3,-chart}][B[t[],x[],y[],z[]]],2 PDchart[{3,-chart}][PDchart[{1,-chart}][\[CapitalEpsilon][t[],x[],y[],z[]]]],2 PDchart[{3,-chart}][PDchart[{2,-chart}][\[CapitalEpsilon][t[],x[],y[],z[]]]],-2 \[Psi][t[],x[],y[],z[]]+2 PDchart[{3,-chart}][PDchart[{3,-chart}][\[CapitalEpsilon][t[],x[],y[],z[]]]]}};
AllComponentValues[Perturbation[metric[-\[Mu],-\[Nu]],1]//ToBasis[chart],metricP1];
metricP2=a[t[]]^2 {{-(2/a[t[]]^2) \[Phi]2[t[],x[],y[],z[]],2/a[t[]] PDchart[{1,-chart}][B2[t[],x[],y[],z[]]],2/a[t[]] PDchart[{2,-chart}][B2[t[],x[],y[],z[]]],2/a[t[]] PDchart[{3,-chart}][B2[t[],x[],y[],z[]]]},{2/a[t[]] PDchart[{1,-chart}][B2[t[],x[],y[],z[]]],-2 \[Psi]2[t[],x[],y[],z[]]+2 PDchart[{1,-chart}][PDchart[{1,-chart}][\[CapitalEpsilon]2[t[],x[],y[],z[]]]],2 PDchart[{1,-chart}][PDchart[{2,-chart}][\[CapitalEpsilon]2[t[],x[],y[],z[]]]],2 PDchart[{1,-chart}][PDchart[{3,-chart}][\[CapitalEpsilon]2[t[],x[],y[],z[]]]]},{2/a[t[]] PDchart[{2,-chart}][B2[t[],x[],y[],z[]]],2 PDchart[{2,-chart}][PDchart[{1,-chart}][\[CapitalEpsilon]2[t[],x[],y[],z[]]]],-2 \[Psi]2[t[],x[],y[],z[]]+2 PDchart[{2,-chart}][PDchart[{2,-chart}][\[CapitalEpsilon]2[t[],x[],y[],z[]]]],2 PDchart[{2,-chart}][PDchart[{3,-chart}][\[CapitalEpsilon]2[t[],x[],y[],z[]]]]},{2/a[t[]] PDchart[{3,-chart}][B2[t[],x[],y[],z[]]],2 PDchart[{3,-chart}][PDchart[{1,-chart}][\[CapitalEpsilon]2[t[],x[],y[],z[]]]],2 PDchart[{3,-chart}][PDchart[{2,-chart}][\[CapitalEpsilon]2[t[],x[],y[],z[]]]],-2 \[Psi]2[t[],x[],y[],z[]]+2 PDchart[{3,-chart}][PDchart[{3,-chart}][\[CapitalEpsilon]2[t[],x[],y[],z[]]]]}};
AllComponentValues[Perturbation[metric[-\[Mu],-\[Nu]],2]//ToBasis[chart],metricP2];


(*DefTensorPerturbation[PertChristoffelcdPDchart[LI[order],\[Xi],-\[Mu],-\[Nu]],ChristoffelcdPDchart[\[Xi],-\[Mu],-\[Nu]],M];*)


(* Torsion and its decompositions *)
torsionvaluebg={{{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}},{{0,-a[t[]]^2h[t[]],0,0},{a[t[]]^2 h[t[]],0,0,0},{0,0,0,2a[t[]]^3 f[t[]]},{0,0,-2 a[t[]]^3 f[t[]],0}},{{0,0,-a[t[]]^2h[t[]],0},{0,0,0,-2 a[t[]]^3 f[t[]]},{a[t[]]^2 h[t[]],0,0,0},{0,2a[t[]]^3 f[t[]],0,0}},{{0,0,0,-a[t[]]^2h[t[]]},{0,0,2a[t[]]^3 f[t[]],0},{0,-2 a[t[]]^3 f[t[]],0,0},{a[t[]]^2 h[t[]],0,0,0}}};
AllComponentValues[Perturbation[TorsionCD[-\[Sigma],-\[Mu],-\[Nu]],0]//ToBasis[chart],torsionvaluebg];
DefTensor[VTorsion[\[Sigma]],M,PrintAs->"V"];
DefTensorPerturbation[PertVTorsion[LI[order],\[Sigma]],VTorsion[\[Sigma]],M,PrintAs->"\[Delta]V"];
DefTensor[ATorsion[\[Sigma]],M,PrintAs->"A"];
DefTensorPerturbation[PertATorsion[LI[order],\[Sigma]],ATorsion[\[Sigma]],M,PrintAs->"\[Delta]A"];
VTorsionP1={\[CapitalXi][t[],x[],y[],z[]],1/a[t[]]PDchart[{1,-chart}][\[CapitalTheta][t[],x[],y[],z[]]],1/a[t[]]PDchart[{2,-chart}][\[CapitalTheta][t[],x[],y[],z[]]],1/a[t[]]PDchart[{3,-chart}][\[CapitalTheta][t[],x[],y[],z[]]]};
ATorsionP1=-2{\[CapitalPhi][t[],x[],y[],z[]],1/a[t[]]PDchart[{1,-chart}][\[CapitalPsi][t[],x[],y[],z[]]],1/a[t[]]PDchart[{2,-chart}][\[CapitalPsi][t[],x[],y[],z[]]],1/a[t[]]PDchart[{3,-chart}][\[CapitalPsi][t[],x[],y[],z[]]]};
AllComponentValues[Perturbation[VTorsion[\[Sigma]],0]//ToBasis[chart],Perturbation[1/3 TorsionCD[\[Mu],\[Sigma],-\[Mu]],0]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues];
AllComponentValues[Perturbation[ATorsion[\[Sigma]],0]//ToBasis[chart],Simplify[(Perturbation[1/6 metric[\[Sigma],\[Zeta]]epsilonmetric[-\[Zeta],-\[Mu],-\[Nu],-\[Xi]]TorsionCD[\[Mu],\[Nu],\[Xi]],0]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToCanonical)/.epsilonToetaDown[metric,chart]//ToValues,a[t[]]>0]];
AllComponentValues[Perturbation[VTorsion[\[Sigma]],1]//ToBasis[chart],VTorsionP1];
AllComponentValues[Perturbation[ATorsion[\[Sigma]],1]//ToBasis[chart],ATorsionP1];
AllComponentValues[Perturbation[TorsionCD[\[Sigma],-\[Mu],-\[Nu]],1]//ToBasis[chart],Simplify[(Perturbation[(metric[-\[Mu],-\[Xi]]VTorsion[\[Xi]]delta[\[Sigma],-\[Nu]]-metric[-\[Nu],-\[Zeta]]VTorsion[\[Zeta]]delta[\[Sigma],-\[Mu]])+metric[\[Sigma],\[Xi]]epsilonmetric[-\[Xi],-\[Mu],-\[Nu],-\[Zeta]]ATorsion[\[Zeta]],1]//ExpandPerturbation//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToCanonical)/.epsilonToetaDown[metric,chart]//ToValues,a[t[]]>0]//ToCanonical];
VTorsionP2={\[CapitalXi]2[t[],x[],y[],z[]],1/a[t[]]PDchart[{1,-chart}][\[CapitalTheta]2[t[],x[],y[],z[]]],1/a[t[]]PDchart[{2,-chart}][\[CapitalTheta]2[t[],x[],y[],z[]]],1/a[t[]]PDchart[{3,-chart}][\[CapitalTheta]2[t[],x[],y[],z[]]]};
ATorsionP2=-2{\[CapitalPhi]2[t[],x[],y[],z[]],1/a[t[]]PDchart[{1,-chart}][\[CapitalPsi]2[t[],x[],y[],z[]]],1/a[t[]]PDchart[{2,-chart}][\[CapitalPsi]2[t[],x[],y[],z[]]],1/a[t[]]PDchart[{3,-chart}][\[CapitalPsi]2[t[],x[],y[],z[]]]};
AllComponentValues[Perturbation[VTorsion[\[Sigma]],2]//ToBasis[chart],VTorsionP2];
AllComponentValues[Perturbation[ATorsion[\[Sigma]],2]//ToBasis[chart],ATorsionP2];
AllComponentValues[Perturbation[TorsionCD[\[Sigma],-\[Mu],-\[Nu]],2]//ToBasis[chart],Simplify[(Perturbation[(metric[-\[Mu],-\[Xi]]VTorsion[\[Xi]]delta[\[Sigma],-\[Nu]]-metric[-\[Nu],-\[Zeta]]VTorsion[\[Zeta]]delta[\[Sigma],-\[Mu]])+metric[\[Sigma],\[Xi]]epsilonmetric[-\[Xi],-\[Mu],-\[Nu],-\[Zeta]]ATorsion[\[Zeta]],2]//ExpandPerturbation//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToCanonical)/.epsilonToetaDown[metric,chart]//ToValues,a[t[]]>0]//ToCanonical];


(* Define an observer *)
DefTensor[u[\[Mu]],M];
u/:u[\[Mu]_]u[-\[Mu]_]:=-1;
DefTensorPerturbation[Pertu[LI[order],\[Mu]],u[\[Mu]],M];
PrintAs[Pertu]^="\[Delta]u";
AllComponentValues[Perturbation[u[\[Mu]],0]//ToBasis[chart],{1,0,0,0}];
uupP1=1/a[t[]] {-a[t[]] \[Phi][t[],x[],y[],z[]],PDchart[{1,-chart}][v[t[],x[],y[],z[]]],PDchart[{2,-chart}][v[t[],x[],y[],z[]]],PDchart[{3,-chart}][v[t[],x[],y[],z[]]]};
AllComponentValues[Perturbation[u[\[Mu]],1]//ToBasis[chart],uupP1];
delta2u0=3 \[Phi][t[],x[],y[],z[]]^2- \[Phi]2[t[],x[],y[],z[]]+4(PDchart[{1,-chart}][B[t[],x[],y[],z[]]]PDchart[{1,-chart}][v[t[],x[],y[],z[]]]+PDchart[{2,-chart}][B[t[],x[],y[],z[]]]PDchart[{2,-chart}][v[t[],x[],y[],z[]]]+PDchart[{3,-chart}][B[t[],x[],y[],z[]]]PDchart[{3,-chart}][v[t[],x[],y[],z[]]])+(PDchart[{1,-chart}][v[t[],x[],y[],z[]]]PDchart[{1,-chart}][v[t[],x[],y[],z[]]]+PDchart[{2,-chart}][v[t[],x[],y[],z[]]]PDchart[{2,-chart}][v[t[],x[],y[],z[]]]+PDchart[{3,-chart}][v[t[],x[],y[],z[]]]PDchart[{3,-chart}][v[t[],x[],y[],z[]]]);
uupP2=1/a[t[]] {a[t[]] delta2u0,PDchart[{1,-chart}][v2[t[],x[],y[],z[]]],PDchart[{2,-chart}][v2[t[],x[],y[],z[]]],PDchart[{3,-chart}][v2[t[],x[],y[],z[]]]};
AllComponentValues[Perturbation[u[\[Mu]],2]//ToBasis[chart],uupP2];


(* Define ADM (3+1) decomposition *)
Off[DefMetric::old];
DefMetric[1,metrich[-\[Mu],-\[Nu]],cdh,{":","\[DifferentialD]"},InducedFrom->{metric,u},PrintAs->"h"];
On[DefMetric::old];
DefTensorPerturbation[Pertmetrich[LI[order],-\[Mu],-\[Nu]],metrich[-\[Mu],-\[Nu]],M,PrintAs->"\[Delta]h"];
DefScalarFunction[lapse];PrintAs[lapse]^="N";
DefTensor[shift[\[Xi]],M,OrthogonalTo->{u[-\[Xi]]},PrintAs->"N"];



(* Define the perfect fluid energy-momentum tensor *)
DefTensor[EMT[\[Mu],-\[Nu]],M,PrintAs->"T"];
DefTensorPerturbation[pertEMT[LI[order],\[Mu],-\[Nu]],EMT[\[Mu],-\[Nu]],M,PrintAs->"\[Delta]T"]
DefScalarFunction[\[Delta]\[Rho]];
DefScalarFunction[\[Delta]p];
DefScalarFunction[\[CapitalPi]];
DefTensor[stress[\[Mu],-\[Nu]],M,PrintAs->"\[CapitalPi]"];
DefTensorPerturbation[pertstress[LI[order],\[Mu],-\[Nu]],stress[\[Mu],-\[Nu]],M,PrintAs->"\[Delta]\[CapitalPi]"];
stress1={{0,0,0,0},{0,PDchart[{1,-chart}][PDchart[{1,-chart}][\[CapitalPi][t[],x[],y[],z[]]]],PDchart[{1,-chart}][PDchart[{2,-chart}][\[CapitalPi][t[],x[],y[],z[]]]],PDchart[{1,-chart}][PDchart[{3,-chart}][\[CapitalPi][t[],x[],y[],z[]]]]},{0,PDchart[{2,-chart}][PDchart[{1,-chart}][\[CapitalPi][t[],x[],y[],z[]]]],PDchart[{2,-chart}][PDchart[{2,-chart}][\[CapitalPi][t[],x[],y[],z[]]]],PDchart[{2,-chart}][PDchart[{3,-chart}][\[CapitalPi][t[],x[],y[],z[]]]]},{0,PDchart[{3,-chart}][PDchart[{1,-chart}][\[CapitalPi][t[],x[],y[],z[]]]],PDchart[{3,-chart}][PDchart[{2,-chart}][\[CapitalPi][t[],x[],y[],z[]]]],PDchart[{3,-chart}][PDchart[{3,-chart}][\[CapitalPi][t[],x[],y[],z[]]]]}}-1/3 (PDchart[{1,-chart}][PDchart[{1,-chart}][\[CapitalPi][t[],x[],y[],z[]]]]+PDchart[{2,-chart}][PDchart[{2,-chart}][\[CapitalPi][t[],x[],y[],z[]]]]+PDchart[{3,-chart}][PDchart[{3,-chart}][\[CapitalPi][t[],x[],y[],z[]]]]){{0,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}}//Simplify;
AllComponentValues[Perturbation[EMT[\[Mu],-\[Nu]],0]//ToBasis[chart],(\[Rho][t[]]+p[t[]])u[\[Mu]]u[-\[Nu]]+p[t[]]metric[\[Mu],-\[Nu]]//SeparateMetric[metric]//ToBasis[chart]//ComponentArray//TraceBasisDummy//ToValues];
AllComponentValues[Perturbation[stress[\[Mu],-\[Nu]],0]//ToBasis[chart],{{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}}];
AllComponentValues[Perturbation[stress[\[Mu],-\[Nu]],1]//ToBasis[chart],stress1];
pertEMT1=(metric[\[Mu],-\[Nu]]\[Delta]p[t[],x[],y[],z[]]+Perturbation[metric[\[Mu],-\[Nu]],1]p[t[]]+Perturbation[u[\[Mu]],1]u[-\[Nu]](\[Rho][t[]]+p[t[]])+Perturbation[u[-\[Nu]],1]u[\[Mu]](\[Rho][t[]]+p[t[]])+u[\[Mu]]u[-\[Nu]](\[Delta]\[Rho][t[],x[],y[],z[]]+\[Delta]p[t[],x[],y[],z[]])+Perturbation[stress[\[Mu],-\[Nu]],1])//SeparateMetric[metric]//ExpandPerturbation//ToBasis[chart]//ComponentArray//TraceBasisDummy//ToValues//ToCanonical;
AllComponentValues[Perturbation[EMT[\[Mu],-\[Nu]],1]//ToBasis[chart],pertEMT1];


(* Define a scalar field phi and its potential V *)
DefTensor[phi[],M,PrintAs->"\[CurlyPhi]"];
DefTensorPerturbation[Pertphi[LI[order]],phi[],M,PrintAs->"\[Delta]\[CurlyPhi]"];
DefScalarFunction[V];

(* For gauge transformation of perturbations *)
DefScalarFunction[\[Xi]0];
DefScalarFunction[\[Xi]i];
DefTensor[gauge[\[Mu]],M];
DefTensorPerturbation[Pertgauge[LI[order],\[Mu]],gauge[\[Mu]],M];
PrintAs[Pertgauge]^="\[Xi]";
(*AllComponentValues[Perturbation[gauge[\[Mu]],0]//ToBasis[chart],{1,0,0,0}];*)
gaugeupP1=1/a[t[]] {a[t[]] \[Xi]0[t[],x[],y[],z[]],PDchart[{1,-chart}][\[Xi]i[t[],x[],y[],z[]]],PDchart[{2,-chart}][\[Xi]i[t[],x[],y[],z[]]],PDchart[{3,-chart}][\[Xi]i[t[],x[],y[],z[]]]};
AllComponentValues[Pertgauge[\[Xi]]//ToBasis[chart],gaugeupP1];


(* Define variables for the simplification of perturbations *)
DefScalarFunction[\[CapitalDelta]\[Phi]];
DefScalarFunction[\[CapitalDelta]\[Psi]];
DefScalarFunction[\[CapitalDelta]B];
DefScalarFunction[\[CapitalDelta]\[CapitalEpsilon]];
DefScalarFunction[\[CapitalDelta]v];
DefScalarFunction[\[CapitalDelta]\[Phi]2];
DefScalarFunction[\[CapitalDelta]\[Psi]2];
DefScalarFunction[\[CapitalDelta]B2];
DefScalarFunction[\[CapitalDelta]\[CapitalEpsilon]2];
DefScalarFunction[\[CapitalDelta]v2];
DefScalarFunction[\[CapitalDelta]\[CapitalXi]];
DefScalarFunction[\[CapitalDelta]\[CapitalPhi]];
DefScalarFunction[\[CapitalDelta]\[CapitalPsi]];
DefScalarFunction[\[CapitalDelta]\[CapitalTheta]];
DefScalarFunction[\[CapitalDelta]2\[CapitalXi]];
DefScalarFunction[\[CapitalDelta]2\[CapitalPhi]];
DefScalarFunction[\[CapitalDelta]2\[CapitalPsi]];
DefScalarFunction[\[CapitalDelta]2\[CapitalTheta]];
DefScalarFunction[\[CapitalDelta]2B];
DefScalarFunction[\[CapitalDelta]2\[CapitalEpsilon]];
DefScalarFunction[\[CapitalDelta]2\[Phi]];
DefScalarFunction[\[CapitalDelta]2\[Psi]];
DefScalarFunction[k2];
simplyRules0[exprs0_,k_]:=Block[{inv,simInv,replaceRules,Y,j=1},inv={x[],y[],z[]};simInv={\[Phi],\[Psi],B,\[CapitalEpsilon],\[CapitalTheta],\[CapitalXi],\[CapitalPhi],\[CapitalPsi],v,\[CapitalPi],\[Phi]2,\[Psi]2,B2,\[CapitalEpsilon]2,v2};Nest[If[SameQ@@(Table[Coefficient[#,D[D[simInv[[j]][t[],x[],y[],z[]],{inv[[i]],2}],{t[],k}]],{i,1,3}]),j++;replaceRules={Plus@@Table[Y_ D[D[simInv[[j-1]][t[],x[],y[],z[]],{inv[[i]],2}],{t[],k}],{i,1,3}]->Y D[ToExpression[StringTemplate["\[CapitalDelta]<*simInv[[j-1]]*>"][]][t[],x[],y[],z[]],{t[],k}],Plus@@Table[D[D[simInv[[j-1]][t[],x[],y[],z[]],{inv[[i]],2}],{t[],k}],{i,1,3}]->D[ToExpression[StringTemplate["\[CapitalDelta]<*simInv[[j-1]]*>"][]][t[],x[],y[],z[]],{t[],k}]};Collect[#,Table[D[D[simInv[[j-1]][t[],x[],y[],z[]],{inv[[i]],2}],{t[],k}],{i,1,3}]]//.replaceRules]&,exprs0,Length@simInv]];
simplyRules[exprs_]:=Block[{k=0},Nest[simplyRules0[#,k++]&,exprs,5]];
simplyRules20[exprs0_,k_]:=Block[{inv,simInv,replaceRules2,Y,jj=1},inv={x[],y[],z[]};simInv={\[Phi],\[Psi],B,\[CapitalEpsilon],\[CapitalTheta],\[CapitalXi],\[CapitalPhi],\[CapitalPsi],v,\[CapitalPi],\[Phi]2,\[Psi]2,B2,\[CapitalEpsilon]2,v2};Nest[If[SameQ@@(Table[Coefficient[#,D[D[simInv[[jj]][t[],x[],y[],z[]],{inv[[i]],4}],{t[],k}]],{i,1,3}])&&SameQ@@({Coefficient[#,D[D[simInv[[jj]][t[],x[],y[],z[]],{inv[[1]],2},{inv[[2]],2}],{t[],k}]],Coefficient[#,D[D[simInv[[jj]][t[],x[],y[],z[]],{inv[[1]],2},{inv[[3]],2}],{t[],k}]],Coefficient[#,D[D[simInv[[jj]][t[],x[],y[],z[]],{inv[[3]],2},{inv[[2]],2}],{t[],k}]]})&&2Table[Coefficient[#,D[D[simInv[[jj]][t[],x[],y[],z[]],{inv[[i]],4}],{t[],k}]],{i,1,3}][[1]]==Coefficient[#,D[D[simInv[[jj]][t[],x[],y[],z[]],{inv[[1]],2},{inv[[2]],2}],{t[],k}]]//Simplify,jj++;replaceRules2={Table[Coefficient[#,D[D[simInv[[jj-1]][t[],x[],y[],z[]],{inv[[i]],4}],{t[],k}]],{i,1,3}].Table[D[D[simInv[[jj-1]][t[],x[],y[],z[]],{inv[[i]],4}],{t[],k}],{i,1,3}]+Coefficient[#,D[D[simInv[[jj-1]][t[],x[],y[],z[]],{inv[[1]],2},{inv[[2]],2}],{t[],k}]]D[D[simInv[[jj-1]][t[],x[],y[],z[]],{inv[[1]],2},{inv[[2]],2}],{t[],k}]+Coefficient[#,D[D[simInv[[jj-1]][t[],x[],y[],z[]],{inv[[3]],2},{inv[[2]],2}],{t[],k}]]D[D[simInv[[jj-1]][t[],x[],y[],z[]],{inv[[3]],2},{inv[[2]],2}],{t[],k}]+Coefficient[#,D[D[simInv[[jj-1]][t[],x[],y[],z[]],{inv[[1]],2},{inv[[3]],2}],{t[],k}]]D[D[simInv[[jj-1]][t[],x[],y[],z[]],{inv[[1]],2},{inv[[3]],2}],{t[],k}]->Table[Coefficient[#,D[D[simInv[[jj-1]][t[],x[],y[],z[]],{inv[[i]],4}],{t[],k}]],{i,1,3}][[1]]D[ToExpression[StringTemplate["\[CapitalDelta]2<*simInv[[jj-1]]*>"][]][t[],x[],y[],z[]],{t[],k}]}//Expand;#//.replaceRules2]&,exprs0,Length@simInv]];
simplyRules2[exprs_]:=Block[{k=0},Nest[simplyRules20[#,k++]&,exprs//Expand,6]];
simplyRules2MapAt[exprs_]:=If[Head[exprs]==Equal,MapAt[simplyRules2,exprs,{{1},{2}}],simplyRules2@exprs];
simplyRules12[exprs_]:=simplyRules2MapAt@simplyRules@exprs;


DefTensor[EinsteinEqleft[\[Mu],\[Nu]],M,Symmetric[{\[Mu],\[Nu]}]];
DefTensor[CartanEqleft[\[Sigma],-\[Mu],-\[Nu]],M,Antisymmetric[{-\[Mu],-\[Nu]}]];
DefTensor[EinsteinCompEqleftT[-\[Mu],-\[Nu]],M];
DefTensor[EinsteinCompEqleftK[-\[Mu],-\[Nu]],M];
DefTensor[CartanCompEqleftT[\[Sigma],-\[Mu],-\[Nu]],M];
DefTensor[CartanCompEqleftK[\[Sigma],-\[Mu],-\[Nu]],M];
DefTensorPerturbation[PertEinsteinEqleft[LI[order],\[Mu],\[Nu]],EinsteinEqleft[\[Mu],\[Nu]],M,Symmetric[{\[Mu],\[Nu]}]];
DefTensorPerturbation[PertCartanEqleft[LI[order],\[Sigma],-\[Mu],-\[Nu]],CartanEqleft[\[Sigma],-\[Mu],-\[Nu]],M,Antisymmetric[{-\[Mu],-\[Nu]}]];
DefTensorPerturbation[PertEinsteinCompEqleftT[LI[order],-\[Mu],-\[Nu]],EinsteinCompEqleftT[-\[Mu],-\[Nu]],M];
DefTensorPerturbation[PertEinsteinCompEqleftK[LI[order],-\[Mu],-\[Nu]],EinsteinCompEqleftK[-\[Mu],-\[Nu]],M];
DefTensorPerturbation[PertCartanCompEqleftT[LI[order],\[Sigma],-\[Mu],-\[Nu]],CartanCompEqleftT[\[Sigma],-\[Mu],-\[Nu]],M];
DefTensorPerturbation[PertCartanCompEqleftK[LI[order],\[Sigma],-\[Mu],-\[Nu]],CartanCompEqleftK[\[Sigma],-\[Mu],-\[Nu]],M];


(*actionGeneralTo2th=-\[Alpha] RicciScalarCD[]+a1 TorsionCD[\[Sigma],-\[Mu],-\[Nu]]TorsionCD[-\[Sigma],\[Mu],\[Nu]]+a2 TorsionCD[-\[Mu],-\[Nu],\[Sigma]]TorsionCD[\[Nu],\[Mu],-\[Sigma]]+a3 TorsionCD[\[Sigma],-\[Mu],-\[Sigma]]TorsionCD[\[Tau],\[Mu],-\[Tau]]+b1 RiemannCD[-\[Mu],-\[Nu],-\[Sigma],-\[Tau]]RiemannCD[\[Mu],\[Nu],\[Sigma],\[Tau]]+b2 RiemannCD[-\[Mu],-\[Nu],-\[Sigma],-\[Tau]]RiemannCD[\[Sigma],\[Tau],\[Mu],\[Nu]]+b3 RicciCD[-\[Mu],-\[Nu]]RicciCD[\[Mu],\[Nu]]+b4 RicciCD[-\[Mu],-\[Nu]]RicciCD[\[Nu],\[Mu]]+b5 RicciScalarCD[]^2+b6(epsilonmetric[-\[Mu],-\[Nu],-\[Sigma],-\[Tau]]RiemannCD[\[Mu],\[Nu],\[Sigma],\[Tau]])(epsilonmetric[\[Beta],\[Gamma],\[Xi],\[Zeta]]RiemannCD[-\[Beta],-\[Gamma],-\[Xi],-\[Zeta]])//ToCanonical;
coef={\[Alpha],a1,a2,a3,b1,b2,b3,b4,b5,b6};
PrintTemporary["The field equations of action by terms are reading."];
length=Length[coef];
time0=AbsoluteTime[];
Monitor[Do[iter+=1;
(*txtEinsteinEqleftAuxT=StringTemplate["EinsteinEqleftAuxT`1`"][coef[[iter]]];
txtEinsteinEqleftAuxK=StringTemplate["EinsteinEqleftAuxK`1`"][coef[[iter]]];
txtCartanEqleftAuxT=StringTemplate["CartanEqleftAuxT`1`"][coef[[iter]]];
txtCartanEqleftAuxK=StringTemplate["CartanEqleftAuxK`1`"][coef[[iter]]];*)
LagrangianDensity[]:=Sqrt[-Detmetric[]]Coefficient[actionGeneralTo2th,coef][[iter]]//ToCanonical;
PertLagrangian[]:=ToCanonical@ContractMetric@ExpandPerturbation@Perturbation@ToCanonical@(BreakChristoffel@NoScalar@ChangeCurvature[LagrangianDensity[],CD,cd]/.Which[$WhichVar==1,rule\[CapitalGamma]/.ruleK,$WhichVar==2,rule\[CapitalGamma]]);
Which[$WhichVar==1,
If[!FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinEqleftAuxT`1`"][coef[[iter]]]}]],
EinsteinEqleftAuxT=ToCanonical@ContractMetric@Symmetrize[metric[-\[Mu],-\[Sigma]]metric[-\[Nu],-\[Tau]]VarD[Perturbation[metric[-\[Sigma],-\[Tau]],1],cd][PertLagrangian[]]/Sqrt[-Detmetric[]]/.delta[-LI[1],LI[1]]->1//ToCanonical,{-\[Mu],-\[Nu]}];
EinsteinEqleftAuxT>>FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinEqleftAuxT`1`"][coef[[iter]]]}]];
If[!FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["CartanEqleftAuxT`1`"][coef[[iter]]]}]],
CartanEqleftAuxT=ToCanonical@ContractMetric@Antisymmetrize[metric[\[Sigma],\[Tau]]metric[-\[Mu],-\[Beta]]metric[-\[Nu],-\[Gamma]]VarD[Perturbation[Which[$WhichVar==1,TorsionCD[\[Tau],-\[Beta],-\[Gamma]],$WhichVar==2,Contorsion[\[Tau],-\[Beta],-\[Gamma]]],1],cd][PertLagrangian[]]/Sqrt[-Detmetric[]]/.delta[-LI[1],LI[1]]->1//ToCanonical,Which[$WhichVar==1,{-\[Mu],-\[Nu]},$WhichVar==2,{\[Sigma],-\[Nu]}]];
CartanEqleftAuxT>>FileNameJoin[{$PackageDirectory,StringTemplate["CartanEqleftAuxT`1`"][coef[[iter]]]}]];,
$WhichVar==2,
If[!FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinEqleftAuxK`1`"][coef[[iter]]]}]],
EinsteinEqleftAuxK=Get[FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinEqleftAuxT`1`"][coef[[iter]]]}]]/.ruleK//ToCanonical;
EinsteinEqleftAuxK>>FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinEqleftAuxK`1`"][coef[[iter]]]}]];
If[!FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["CartanEqleftAuxK`1`"][coef[[iter]]]}]],
CartanEqleftAuxK=Get[FileNameJoin[{$PackageDirectory,StringTemplate["CartanEqleftAuxT`1`"][coef[[iter]]]}]]/.ruleK//ToCanonical;
CartanEqleftAuxK>>FileNameJoin[{$PackageDirectory,StringTemplate["CartanEqleftAuxK`1`"][coef[[iter]]]}]];];,{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];
time1=AbsoluteTime[];
Print[StringTemplate["The field equations of action by terms have been written. Absolute timing: `1`seconds, `2`minutes, `3`hours."][time1-time0,(time1-time0)/60,(time1-time0)/3600]];*)


(* Pre-writing some time consuming terms *)
AllComponentValues[Perturbation[TorsionCD[#1,#2,#3],0]//ToBasis[chart],Perturbation[metric[#1,\[Tau]]metric[#2,\[Beta]]metric[#3,\[Gamma]]TorsionCD[-\[Tau],-\[Beta],-\[Gamma]],0]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues]&@@@Delete[Tuples[{{\[Sigma],-\[Sigma]},{\[Mu],-\[Mu]},{\[Nu],-\[Nu]}}],8];
Print["The components of TorsionCD have been written."];
Print[PGC027`bars];
AllComponentValues[Perturbation[Riccicd[#1,#2],0]//ToBasis[chart],Perturbation[metric[#1,\[Beta]]metric[#2,\[Gamma]]Riccicd[-\[Beta],-\[Gamma]],0]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues]&@@@Tuples[{{\[Mu],-\[Mu]},{\[Nu],-\[Nu]}}];
Print["The components of Riccicd have been written."];
Print[PGC027`bars];
AllComponentValues[ChristoffelcdPDchart[#1,#2,#3]//ToBasis[chart],(metric[#1,\[Tau]]metric[#2,\[Beta]]metric[#3,\[Gamma]]ChristoffelcdPDchart[-\[Tau],-\[Beta],-\[Gamma]])//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues]&@@@Tuples[{{\[Sigma],-\[Sigma]},{\[Mu],-\[Mu]},{\[Nu],-\[Nu]}}];
Print["The components of ChristoffelcdPDchart have been written."];
Print[PGC027`bars];
AllComponentValues[ChristoffelcdhPDchart[#1,#2,#3]//ToBasis[chart],(ProjectorToMetric[ChristoffelcdhPDchart[#1,#2,#3]//ChristoffelToMetric,metrich])//SeparateMetric[metric]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues]&@@@Tuples[{{\[Sigma],-\[Sigma]},{\[Mu],-\[Mu]},{\[Nu],-\[Nu]}}];
Print["The components of ChristoffelcdhPDchart have been written."];
Print[PGC027`bars];
AllComponentValues[metrich[#1,#2]//ToBasis[chart],Perturbation[ProjectorToMetric[metrich[#1,#2],metrich],0]//ExpandPerturbation//SeparateMetric[metric]//ToBasis[chart]//ToBasis[chart]//ComponentArray//TraceBasisDummy//ToValues//ToValues//ToCanonical]&@@@Tuples[{{\[Sigma],-\[Sigma]},{\[Mu],-\[Mu]}}];
Print["The components of induced metric h have been written."];
Print[PGC027`bars];
AllComponentValues[Perturbation[metrich[-\[Mu],-\[Nu]],1]//ToBasis[chart],Perturbation[ProjectorToMetric[metrich[-\[Mu],-\[Nu]],metrich],1]//ExpandPerturbation//SeparateMetric[metric]//ToBasis[chart]//ToBasis[chart]//ComponentArray//TraceBasisDummy//ToValues//ToValues//ToCanonical];
Print["The components of 1st order canonical perturbed induced metric \[Delta]h have been written."];
Print[PGC027`bars];
DefTensor[cdTorsionCD[\[Sigma],-\[Mu],-\[Nu],-\[Tau]],M,Antisymmetric[{-\[Mu],-\[Nu]}],PrintAs->"DT"];
DefTensor[cdcdTorsionCD[\[Sigma],-\[Mu],-\[Nu],-\[Tau],-\[Beta]],M,Antisymmetric[{-\[Mu],-\[Nu]}],PrintAs->"\!\(\*SuperscriptBox[\(D\), \(2\)]\)T"];
DefTensor[cdcdcdTorsionCD[\[Sigma],-\[Mu],-\[Nu],-\[Tau],-\[Beta],-\[Gamma]],M,Antisymmetric[{-\[Mu],-\[Nu]}],PrintAs->"\!\(\*SuperscriptBox[\(D\), \(3\)]\)T"];
DefTensor[cdcdRiemanncd[-\[Mu],-\[Nu],-\[Sigma],-\[Tau],-\[Beta],-\[Gamma]],M,RiemannSymmetric[{-\[Mu],-\[Nu],-\[Sigma],-\[Tau]}],PrintAs->"DDRie"];
DefTensor[cdRiccicd[-\[Sigma],-\[Mu],-\[Nu]],M,Symmetric[{-\[Sigma],-\[Mu]}],PrintAs->"DR"];
DefTensor[cdcdRiccicd[-\[Sigma],-\[Mu],-\[Nu],-\[Tau]],M,Symmetric[{-\[Sigma],-\[Mu]}],PrintAs->"\!\(\*SuperscriptBox[\(D\), \(2\)]\)R"];
DefTensor[cdRicciScalarcd[-\[Tau]],M,PrintAs->"DRs"];
DefTensor[cdcdRicciScalarcd[-\[Tau],-\[Sigma]],M,PrintAs->"DDRs"];
DefTensor[cddeltametric[-\[Sigma],-\[Mu],-\[Nu]],M,Symmetric[{-\[Sigma],-\[Mu]}],PrintAs->"D\[Delta]g"];
DefTensor[cdcddeltametric[-\[Sigma],-\[Mu],-\[Nu],-\[Tau]],M,Symmetric[{-\[Sigma],-\[Mu]}],PrintAs->"DD\[Delta]g"];
DefTensor[cdcdcddeltametric[-\[Sigma],-\[Mu],-\[Nu],-\[Tau],-\[Beta]],M,Symmetric[{-\[Sigma],-\[Mu]}],PrintAs->"DDD\[Delta]g"];
DefTensor[cdcdcdcddeltametric[-\[Sigma],-\[Mu],-\[Nu],-\[Tau],-\[Beta],-\[Gamma]],M,Symmetric[{-\[Sigma],-\[Mu]}],PrintAs->"DDDD\[Delta]g"];
DefTensor[cddeltaTorsion[\[Sigma],-\[Mu],-\[Nu],-\[Tau]],M,Antisymmetric[{-\[Mu],-\[Nu]}],PrintAs->"D\[Delta]T"];
DefTensor[cdcddeltaTorsion[\[Sigma],-\[Mu],-\[Nu],-\[Tau],-\[Beta]],M,Antisymmetric[{-\[Mu],-\[Nu]}],PrintAs->"DD\[Delta]T"];
DefTensor[cdcdcddeltaTorsion[\[Sigma],-\[Mu],-\[Nu],-\[Tau],-\[Beta],-\[Gamma]],M,Antisymmetric[{-\[Mu],-\[Nu]}],PrintAs->"DDD\[Delta]T"];
ruleDiffReplace={cd[\[Gamma]_]@cd[\[Beta]_]@cd[\[Tau]_]@TorsionCD[\[Sigma]_,\[Mu]_,\[Nu]_]->cdcdcdTorsionCD[\[Sigma],\[Mu],\[Nu],\[Tau],\[Beta],\[Gamma]],cd[\[Beta]_]@cd[\[Tau]_]@TorsionCD[\[Sigma]_,\[Mu]_,\[Nu]_]->cdcdTorsionCD[\[Sigma],\[Mu],\[Nu],\[Tau],\[Beta]],cd[\[Tau]_]@TorsionCD[\[Sigma]_,\[Mu]_,\[Nu]_]->cdTorsionCD[\[Sigma],\[Mu],\[Nu],\[Tau]],cd[\[Gamma]_]@cd[\[Beta]_]@Riemanncd[\[Mu]_,\[Nu]_,\[Sigma]_,\[Tau]_]->cdcdRiemanncd[\[Mu],\[Nu],\[Sigma],\[Tau],\[Beta],\[Gamma]],cd[\[Beta]_]@Riemanncd[\[Mu]_,\[Nu]_,\[Sigma]_,\[Tau]_]->cdRiemanncd[\[Mu],\[Nu],\[Sigma],\[Tau],\[Beta]],cd[\[Tau]_]@cd[\[Nu]_]@Riccicd[\[Sigma]_,\[Mu]_]->cdcdRiccicd[\[Sigma],\[Mu],\[Nu],\[Tau]],cd[\[Nu]_]@Riccicd[\[Sigma]_,\[Mu]_]->cdRiccicd[\[Sigma],\[Mu],\[Nu]],cd[\[Tau]_]@cd[\[Sigma]_]@RicciScalarcd[]->cdcdRicciScalarcd[\[Sigma],\[Tau]],cd[\[Sigma]_]@RicciScalarcd[]->cdRicciScalarcd[\[Sigma]]};
ruleDeltaReplace={cd[\[Nu]_][cd[\[Beta]_][cd[\[Tau]_][cd[\[Sigma]_][metpert[LI[1],\[Gamma]_,\[Mu]_]]]]]->cdcdcdcddeltametric[\[Gamma],\[Mu],\[Sigma],\[Tau],\[Beta],\[Nu]],cd[\[Beta]_][cd[\[Tau]_][cd[\[Sigma]_][metpert[LI[1],\[Gamma]_,\[Mu]_]]]]->cdcdcddeltametric[\[Gamma],\[Mu],\[Sigma],\[Tau],\[Beta]],cd[\[Tau]_][cd[\[Sigma]_][metpert[LI[1],\[Beta]_,\[Mu]_]]]->cdcddeltametric[\[Beta],\[Mu],\[Sigma],\[Tau]],cd[\[Sigma]_][metpert[LI[1],\[Beta]_,\[Mu]_]]->cddeltametric[\[Beta],\[Mu],\[Sigma]],cd[-\[Gamma]_][cd[-\[Beta]_][cd[-\[Tau]_][PertTorsion[LI[1],\[Sigma]_,-\[Mu]_,-\[Nu]_]]]]->cdcdcddeltaTorsion[\[Sigma],-\[Mu],-\[Nu],-\[Tau],-\[Beta],-\[Gamma]],cd[-\[Beta]_][cd[-\[Tau]_][PertTorsion[LI[1],\[Sigma]_,-\[Mu]_,-\[Nu]_]]]->cdcddeltaTorsion[\[Sigma],-\[Mu],-\[Nu],-\[Tau],-\[Beta]],cd[-\[Tau]_][PertTorsion[LI[1],\[Sigma]_,-\[Mu]_,-\[Nu]_]]->cddeltaTorsion[\[Sigma],-\[Mu],-\[Nu],-\[Tau]]};
Module[{iter=0,length},
PrintTemporary["The components of cdTorsionCD are enumerating."];length=Length[Tuples[{{\[Sigma],-\[Sigma]},{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Tau],-\[Tau]}}]];Monitor[Table[iter+=1;AllComponentValues[Perturbation[cdTorsionCD[#1,#2,#3,#4],0]//ToBasis[chart],Perturbation[cd[#4]@TorsionCD[#1,#2,#3],0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues]&@@Tuples[{{\[Sigma],-\[Sigma]},{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Tau],-\[Tau]}}][[iter]],{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];Print["The components of cdTorsionCD have been written."];];//AbsoluteTiming
Print[PGC027`bars];
(*Module[{iter=0,length},
PrintTemporary["The components of cdcdTorsionCD are enumerating."];length=Length[Tuples[{{\[Sigma],-\[Sigma]},{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Tau],-\[Tau]},{\[Beta],-\[Beta]}}]];Monitor[Table[iter+=1;AllComponentValues[Perturbation[cdcdTorsionCD[#1,#2,#3,#4,#5],0]//ToBasis[chart],Once[Perturbation[cd[#5]@cdTorsionCD[#1,#2,#3,#4],0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues,"Local"]]&@@Tuples[{{\[Sigma],-\[Sigma]},{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Tau],-\[Tau]},{\[Beta],-\[Beta]}}][[iter]],{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];Print["The components of cdcdTorsionCD have been written."];];//AbsoluteTiming]*)
(*Module[{iter=0,length},
PrintTemporary["The components of cdcdcdTorsionCD are enumerating."];length=Length[Tuples[{{b,-b},{c,-c},{d,-d},{e,-e},{g,-g},{i,-i}}]];Monitor[Table[iter+=1;AllComponentValues[Perturbation[cdcdcdTorsionCD[#1,#2,#3,#4,#5,#6],0]//ToBasis[chart],Once[Perturbation[cd[#6]@cdcdTorsionCD[#1,#2,#3,#4,#5],0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues,"Local"]]&@@Tuples[{{b,-b},{c,-c},{d,-d},{e,-e},{g,-g},{i,-i}}][[iter]],{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];Print["The components of cdcdcdTorsionCD have been written."];];//AbsoluteTiming*)
Module[{},
PrintTemporary["The components of cdcdTorsionCD are enumerating."];AllComponentValues[Perturbation[cdcdTorsionCD[\[Sigma],-\[Mu],-\[Nu],-\[Tau],-\[Beta]],0]//ToBasis[chart],Perturbation[cd[-\[Beta]]@cdTorsionCD[\[Sigma],-\[Mu],-\[Nu],-\[Tau]],0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues];Print["The components of cdcdTorsionCD have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{},
PrintTemporary["The components of cdcdcdTorsionCD are enumerating."];AllComponentValues[Perturbation[cdcdcdTorsionCD[\[Sigma],-\[Mu],-\[Nu],-\[Tau],-\[Beta],-\[Gamma]],0]//ToBasis[chart],Perturbation[cd[-\[Gamma]]@cdcdTorsionCD[\[Sigma],-\[Mu],-\[Nu],-\[Tau],-\[Beta]],0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues];Print["The components of cdcdcdTorsionCD have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{iter=0,length},
PrintTemporary["The components of Riemanncd are enumerating."];length=Length[Tuples[{{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Sigma],-\[Sigma]},{\[Tau],-\[Tau]}}]];Monitor[Table[iter+=1;AllComponentValues[Perturbation[Riemanncd[#1,#2,#3,#4],0]//ToBasis[chart],Perturbation[Riemanncd[#1,#2,#3,#4],0]//SeparateMetric[metric]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues]&@@Tuples[{{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Sigma],-\[Sigma]},{\[Tau],-\[Tau]}}][[iter]],{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];Print["The components of Riemanncd have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{iter=0,length},
PrintTemporary["The components of cdcdRiemanncd are enumerating."];AllComponentValues[Perturbation[cdcdRiemanncd[-\[Mu],-\[Nu],-\[Sigma],-\[Tau],-\[Beta],-\[Gamma]],0]//ToBasis[chart],Perturbation[cd[-\[Gamma]]@cdRiemanncd[-\[Mu],-\[Nu],-\[Sigma],-\[Tau],-\[Beta]],0]//SeparateMetric[metric]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues];Print["The components of cdcdRiemanncd have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{iter=0,length},
PrintTemporary["The components of cdRiccicd are enumerating."];length=Length[Tuples[{{\[Sigma],-\[Sigma]},{\[Mu],-\[Mu]},{\[Nu],-\[Nu]}}]];Monitor[Table[iter+=1;AllComponentValues[Perturbation[cdRiccicd[#1,#2,#3],0]//ToBasis[chart],Perturbation[cd[#3]@Riccicd[#1,#2],0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues]&@@Tuples[{{\[Sigma],-\[Sigma]},{\[Mu],-\[Mu]},{\[Nu],-\[Nu]}}][[iter]],{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];Print["The components of cdRiccicd have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{iter=0,length},
PrintTemporary["The components of cdcdRiccicd are enumerating."];length=Length[Tuples[{{\[Sigma],-\[Sigma]},{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Tau],-\[Tau]}}]];Monitor[Table[iter+=1;AllComponentValues[Perturbation[cdcdRiccicd[#1,#2,#3,#4],0]//ToBasis[chart],Perturbation[cd[#4]@cdRiccicd[#1,#2,#3],0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues]&@@Tuples[{{\[Sigma],-\[Sigma]},{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Tau],-\[Tau]}}][[iter]],{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];Print["The components of cdcdRiccicd have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{iter=0,length},
PrintTemporary["The components of cdRicciScalarcd are enumerating."];length=Length[Tuples[{{\[Sigma],-\[Sigma]}}]];Monitor[Table[iter+=1;AllComponentValues[Perturbation[cdRicciScalarcd[#1],0]//ToBasis[chart],Perturbation[cd[#1]@RicciScalarcd[],0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues]&@@Tuples[{{\[Sigma],-\[Sigma]}}][[iter]],{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];Print["The components of cdRicciScalarcd have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{iter=0,length},
PrintTemporary["The components of cdcdRicciScalarcd are enumerating."];length=Length[Tuples[{{\[Sigma],-\[Sigma]},{\[Tau],-\[Tau]}}]];Monitor[Table[iter+=1;AllComponentValues[Perturbation[cdcdRicciScalarcd[#1,#2],0]//ToBasis[chart],Perturbation[cd[#2]@cdRicciScalarcd[#1],0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues]&@@Tuples[{{\[Sigma],-\[Sigma]},{\[Tau],-\[Tau]}}][[iter]],{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];Print["The components of cdcdRicciScalarcd have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{iter=0,length},
PrintTemporary["The components of deltametric are enumerating."];length=Length[Tuples[{{\[Mu],-\[Mu]},{\[Nu],-\[Nu]}}]];Monitor[Table[iter+=1;AllComponentValues[Perturbation[metpert[LI[1],#1,#2],0]//ToBasis[chart],Perturbation[metpert[LI[1],#1,#2],0]//ExpandPerturbation//SeparateMetric[metric]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues//ToCanonical//SeparateMetric[metric]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToCanonical]&@@Tuples[{{\[Mu],-\[Mu]},{\[Nu],-\[Nu]}}][[iter]],{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];Print["The components of deltametric have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{iter=0,length},
PrintTemporary["The components of cddeltametric are enumerating."];length=Length[Tuples[{{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Tau],-\[Tau]}}]];Monitor[Table[iter+=1;AllComponentValues[Perturbation[cddeltametric[#1,#2,#3],0]//ToBasis[chart],Perturbation[cd[#3]@metpert[LI[1],#1,#2],0]//ExpandPerturbation//SeparateMetric[metric]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues//ToCanonical//SeparateMetric[metric]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToCanonical]&@@Tuples[{{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Tau],-\[Tau]}}][[iter]],{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];Print["The components of cddeltametric have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{iter=0,length},
PrintTemporary["The components of cdcddeltametric are enumerating."];length=Length[Tuples[{{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Tau],-\[Tau]},{\[Sigma],-\[Sigma]}}]];Monitor[Table[iter+=1;AllComponentValues[Perturbation[cdcddeltametric[#1,#2,#3,#4],0]//ToBasis[chart],Perturbation[cd[#4]@cddeltametric[#1,#2,#3],0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues//ToCanonical]&@@Tuples[{{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Tau],-\[Tau]},{\[Sigma],-\[Sigma]}}][[iter]],{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];Print["The components of cdcddeltametric have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{},
PrintTemporary["The components of cdcdcddeltametric are enumerating."];AllComponentValues[Perturbation[cdcdcddeltametric[-\[Mu],-\[Nu],-\[Sigma],-\[Tau],-\[Beta]],0]//ToBasis[chart],Perturbation[cd[-\[Beta]]@cdcddeltametric[-\[Mu],-\[Nu],-\[Sigma],-\[Tau]],0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues//ToCanonical];Print["The components of cdcdcddeltametric have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{},
PrintTemporary["The components of cdcdcdcddeltametric are enumerating."];AllComponentValues[Perturbation[cdcdcdcddeltametric[-\[Mu],-\[Nu],-\[Sigma],-\[Tau],-\[Beta],-\[Gamma]],0]//ToBasis[chart],Perturbation[cd[-\[Gamma]]@cdcdcddeltametric[-\[Mu],-\[Nu],-\[Sigma],-\[Tau],-\[Beta]],0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues//ToCanonical];Print["The components of cdcdcdcddeltametric have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{iter=0,length},
PrintTemporary["The components of deltaTorsionCD are enumerating."];length=Length[Tuples[{{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Tau],-\[Tau]}}]];Monitor[Table[iter+=1;AllComponentValues[Perturbation[PertTorsion[LI[1],#1,#2,#3],0]//ToBasis[chart],Perturbation[PertTorsion[LI[1],#1,#2,#3],0]//ExpandPerturbation//SeparateMetric[metric]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues//ToCanonical//SeparateMetric[metric]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToCanonical]&@@Tuples[{{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Tau],-\[Tau]}}][[iter]],{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];Print["The components of deltaTorsionCD have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{iter=0,length},
PrintTemporary["The components of cddeltaTorsionCD are enumerating."];length=Length[Tuples[{{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Tau],-\[Tau]},{\[Sigma],-\[Sigma]}}]];Monitor[Table[iter+=1;AllComponentValues[Perturbation[cddeltaTorsion[#1,#2,#3,#4],0]//ToBasis[chart],Perturbation[cd[#4]@PertTorsion[LI[1],#1,#2,#3],0]//ExpandPerturbation//SeparateMetric[metric]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues//ToCanonical//SeparateMetric[metric]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToCanonical]&@@Tuples[{{\[Mu],-\[Mu]},{\[Nu],-\[Nu]},{\[Tau],-\[Tau]},{\[Sigma],-\[Sigma]}}][[iter]],{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];Print["The components of cddeltaTorsionCD have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{},
PrintTemporary["The components of cdcddeltaTorsionCD are enumerating."];AllComponentValues[Perturbation[cdcddeltaTorsion[\[Sigma],-\[Mu],-\[Nu],-\[Tau],-\[Beta]],0]//ToBasis[chart],Perturbation[cd[-\[Beta]]@cddeltaTorsion[\[Sigma],-\[Mu],-\[Nu],-\[Tau]],0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues//ToCanonical];Print["The components of cdcddeltaTorsionCD have been written."];];//AbsoluteTiming
Print[PGC027`bars];
Module[{},
PrintTemporary["The components of cdcdcddeltaTorsionCD are enumerating."];AllComponentValues[Perturbation[cdcdcddeltaTorsion[\[Sigma],-\[Mu],-\[Nu],-\[Tau],-\[Beta],-\[Gamma]],0]//ToBasis[chart],Perturbation[cd[-\[Gamma]]@cdcddeltaTorsion[\[Sigma],-\[Mu],-\[Nu],-\[Tau],-\[Beta]],0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues//ToCanonical];Print["The components of cdcdcddeltaTorsionCD have been written."];];//AbsoluteTiming
Print[PGC027`bars];


(* the Lagrangian density and its perturbation *)
(*LagrangianDensity[]:=Sqrt[-Detmetric[] ](RicciScalarCD[]+2\[Alpha] RicciScalarCD[]^2+2\[Beta] RicciCD[-b,-c]RicciCD[b,c]+2\[Gamma] TorsionCD[d,-e,-i]TorsionCD[-d,e,i]);*)
actionGeneralTo2th=\[Alpha] RicciScalarCD[]+a1 TorsionCD[\[Sigma],-\[Mu],-\[Nu]]TorsionCD[-\[Sigma],\[Mu],\[Nu]]+a2 TorsionCD[-\[Mu],-\[Nu],\[Sigma]]TorsionCD[\[Nu],\[Mu],-\[Sigma]]+a3 TorsionCD[\[Sigma],-\[Mu],-\[Sigma]]TorsionCD[\[Tau],\[Mu],-\[Tau]]+b1 RiemannCD[-\[Mu],-\[Nu],-\[Sigma],-\[Tau]]RiemannCD[\[Mu],\[Nu],\[Sigma],\[Tau]]+b2 RiemannCD[-\[Mu],-\[Nu],-\[Sigma],-\[Tau]]RiemannCD[\[Sigma],\[Tau],\[Mu],\[Nu]]+b3 RicciCD[-\[Mu],-\[Nu]]RicciCD[\[Mu],\[Nu]]+b4 RicciCD[-\[Mu],-\[Nu]]RicciCD[\[Nu],\[Mu]]+b5 RicciScalarCD[]^2+b6(epsilonmetric[-\[Mu],-\[Nu],-\[Sigma],-\[Tau]]RiemannCD[\[Mu],\[Nu],\[Sigma],\[Tau]])(epsilonmetric[\[Beta],\[Gamma],\[Xi],\[Zeta]]RiemannCD[-\[Beta],-\[Gamma],-\[Xi],-\[Zeta]])+c1 RiemannCD[-\[Mu],-\[Nu],-\[Sigma],-\[Tau]]RiemannCD[\[Mu],\[Sigma],\[Nu],\[Tau]]//ToCanonical;
coef={\[Alpha],a1,a2,a3,b1,b2,b3,b4,b5,b6,c1};
pert0Replace[Eqs_]:=Perturbation[Eqs,0]//.ruleDiffReplace;
pert1Replace[Eqs_]:=((Perturbation[Eqs,1]//ExpandPerturbation)//.ruleDeltaReplace//.ruleDiffReplace)//Expand//ToCanonical//ContractMetric;
parallel[pert_]:=If[MatchQ[pert,Y_ cdcdRiemanncd[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_,\[Gamma]_]]||MatchQ[pert,cdcdRiemanncd[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_,\[Gamma]_]]||MatchQ[pert,Y_ cdRiemanncd[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_]]||MatchQ[pert,cdRiemanncd[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_]]||MatchQ[pert,Y_ cdcdcdTorsionCD[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_,\[Gamma]_]]||MatchQ[pert,cdcdcdTorsionCD[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_,\[Gamma]_]]||MatchQ[pert,Y_ cdcdTorsionCD[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_]]||MatchQ[pert,cdcdTorsionCD[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_]]||MatchQ[pert,Y_ cdcdcdcddeltametric[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_,\[Gamma]_]]||MatchQ[pert,cdcdcdcddeltametric[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_,\[Gamma]_]]||MatchQ[pert,Y_ cdcdcddeltametric[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_]]||MatchQ[pert,cdcdcddeltametric[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_]]||MatchQ[pert,Y_ cdcdcddeltaTorsion[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_,\[Gamma]_]]||MatchQ[pert,cdcdcddeltaTorsion[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_,\[Gamma]_]]||MatchQ[pert,Y_ cdcddeltaTorsion[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_]]||MatchQ[pert,cdcddeltaTorsion[\[Sigma]_,\[Mu]_,\[Nu]_,\[Tau]_,\[Beta]_]],pert//SeparateMetric[metric]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues//ToCanonical,pert//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues//ToCanonical];
PrintTemporary["The field equations of action by terms are reading."];
length=Length[coef];
time0=AbsoluteTime[];
Monitor[Do[iter+=1;
LagrangianDensity[]:=Sqrt[-Detmetric[]]Coefficient[actionGeneralTo2th,coef][[iter]];
PertLagrangian[]:=ToCanonical@ContractMetric@ExpandPerturbation@Perturbation@ToCanonical@(BreakChristoffel@NoScalar@ChangeCurvature[LagrangianDensity[],CD,cd]/.Which[$WhichVar==1,rule\[CapitalGamma]/.ruleK,$WhichVar==2,rule\[CapitalGamma]]);
(* Variations *)
If[!(FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinEqleftAuxT`1`"][coef[[iter]]]}]]&&FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinEqleftAuxK`1`"][coef[[iter]]]}]]&&FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["CartanEqleftAuxT`1`"][coef[[iter]]]}]]&&FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["CartanEqleftAuxK`1`"][coef[[iter]]]}]]),
EinsteinEqleft/:EinsteinEqleft[\[Mu]_,\[Nu]_]:=ToCanonical@ContractMetric@Symmetrize[metric[\[Mu],-\[Sigma]]metric[\[Nu],-\[Tau]]VarD[Perturbation[metric[-\[Sigma],-\[Tau]],1],cd][PertLagrangian[]]/Sqrt[-Detmetric[]]/.delta[-LI[1],LI[1]]->1//ToCanonical,{\[Mu],\[Nu]}];
CartanEqleft/:CartanEqleft[\[Sigma]_,\[Mu]_,\[Nu]_]:=ToCanonical@ContractMetric@Antisymmetrize[metric[\[Sigma],\[Tau]]metric[\[Mu],-\[Beta]]metric[\[Nu],-\[Gamma]]VarD[Perturbation[Which[$WhichVar==1,TorsionCD[\[Tau],-\[Beta],-\[Gamma]],$WhichVar==2,Contorsion[\[Tau],-\[Beta],-\[Gamma]]],1],cd][PertLagrangian[]]/Sqrt[-Detmetric[]]/.delta[-LI[1],LI[1]]->1//ToCanonical,Which[$WhichVar==1,{\[Mu],\[Nu]},$WhichVar==2,{\[Sigma],\[Nu]}]];
(* Symmetrization *)
EinsteinEqleftAuxT=EinsteinEqleft[-\[Mu],-\[Nu]]//ToCanonical;
EinsteinEqleftAuxK=EinsteinEqleft[-\[Mu],-\[Nu]]/.ruleK//ToCanonical;
CartanEqleftAuxT=CartanEqleft[\[Sigma],-\[Mu],-\[Nu]]//ToCanonical;
CartanEqleftAuxK=CartanEqleft[\[Sigma],-\[Mu],-\[Nu]]/.ruleK//ToCanonical;

Put[EinsteinEqleftAuxT,FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinEqleftAuxT`1`"][coef[[iter]]]}]];
Put[CartanEqleftAuxT,FileNameJoin[{$PackageDirectory,StringTemplate["CartanEqleftAuxT`1`"][coef[[iter]]]}]];
Put[EinsteinEqleftAuxK,FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinEqleftAuxK`1`"][coef[[iter]]]}]];
Put[CartanEqleftAuxK,FileNameJoin[{$PackageDirectory,StringTemplate["CartanEqleftAuxK`1`"][coef[[iter]]]}]];,

EinsteinEqleftAuxT=Get[FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinEqleftAuxT`1`"][coef[[iter]]]}]];
CartanEqleftAuxT=Get[FileNameJoin[{$PackageDirectory,StringTemplate["CartanEqleftAuxT`1`"][coef[[iter]]]}]];
EinsteinEqleftAuxK=Get[FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinEqleftAuxK`1`"][coef[[iter]]]}]];
CartanEqleftAuxK=Get[FileNameJoin[{$PackageDirectory,StringTemplate["CartanEqleftAuxK`1`"][coef[[iter]]]}]];];

(* the components of Einstein and Cartan left parts *)
Off[General::argx];
(* the components of Equations of fields on the background*)
If[!FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinCompEqleftT`1`"][coef[[iter]]]}]],
EinsteinCompEqleftT=Plus@@ParallelTable[parallel[#]&@pert0Replace[EinsteinEqleftAuxT][[ii]],{ii,1,Length@pert0Replace[EinsteinEqleftAuxT]},DistributedContexts->Automatic,Method->"FinestGrained"]//Simplification;
Put[EinsteinCompEqleftT,FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinCompEqleftT`1`"][coef[[iter]]]}]];];

(*If[!FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinCompEqleftK`1`"][coef[[iter]]]}]],
EinsteinCompEqleftK=Plus@@ParallelTable[parallel[#]&@pert0Replace[EinsteinEqleftAuxK][[ii]],{ii,1,Length@pert0Replace[EinsteinEqleftAuxK]},DistributedContexts->Automatic,Method->"FinestGrained"]//Simplification;
EinsteinCompEqleftK>>FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinCompEqleftK`1`"][coef[[iter]]]}];];*)

If[!FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["CartanCompEqleftT`1`"][coef[[iter]]]}]],
CartanCompEqleftT=If[iter==2||iter==3||iter==4,parallel[#]&@pert0Replace[CartanEqleftAuxT]//Simplification,Plus@@ParallelTable[parallel[#]&@pert0Replace[CartanEqleftAuxT][[ii]],{ii,1,Length@pert0Replace[CartanEqleftAuxT]},DistributedContexts->Automatic,Method->"FinestGrained"]//Simplification];
Put[CartanCompEqleftT,FileNameJoin[{$PackageDirectory,StringTemplate["CartanCompEqleftT`1`"][coef[[iter]]]}]];];

(*If[!FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["CartanCompEqleftK`1`"][coef[[iter]]]}]],
CartanCompEqleftK=Plus@@ParallelTable[parallel[#]&@pert0Replace[CartanEqleftAuxK][[ii]],{ii,1,Length@pert0Replace[CartanEqleftAuxK]},DistributedContexts->Automatic,Method->"FinestGrained"]//Simplification;
CartanCompEqleftK>>FileNameJoin[{$PackageDirectory,StringTemplate["CartanCompEqleftK`1`"][coef[[iter]]]}];];*)

(* the components of Equations of fields on the 1st order *)
(* close temp *)
If[!FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["pert1EinsteinCompEqleftT`1`"][coef[[iter]]]}]],
pert1EinsteinEqleftAuxT=pert1Replace[EinsteinEqleftAuxT];
pert1EinsteinCompEqleftT=Plus@@ParallelTable[parallel[#]&@pert1EinsteinEqleftAuxT[[ii]],{ii,1,Length@pert1EinsteinEqleftAuxT},DistributedContexts->Automatic,Method->"FinestGrained"]//Simplification;
Put[pert1EinsteinCompEqleftT,FileNameJoin[{$PackageDirectory,StringTemplate["pert1EinsteinCompEqleftT`1`"][coef[[iter]]]}]];];

(*If[!FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["pert1EinsteinCompEqleftK`1`"][coef[[iter]]]}]],
pert1EinsteinEqleftAuxK=pert1Replace[EinsteinEqleftAuxK];
pert1EinsteinCompEqleftK=Plus@@ParallelTable[parallel[#]&@pert1EinsteinEqleftAuxK[[ii]],{ii,1,Length@pert1EinsteinEqleftAuxK},DistributedContexts->Automatic,Method->"FinestGrained"]//Simplification;
pert1EinsteinCompEqleftK>>FileNameJoin[{$PackageDirectory,StringTemplate["pert1EinsteinCompEqleftK`1`"][coef[[iter]]]}];];*)

(* close temp *)
If[!FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["pert1CartanCompEqleftT`1`"][coef[[iter]]]}]],
pert1CartanEqleftAuxT=pert1Replace[CartanEqleftAuxT];
pert1CartanCompEqleftT=If[iter==2||iter==3||iter==4,parallel[#]&@pert1CartanEqleftAuxT//Simplification,Plus@@ParallelTable[parallel[#]&@pert1CartanEqleftAuxT[[ii]],{ii,1,Length@pert1CartanEqleftAuxT},DistributedContexts->Automatic,Method->"FinestGrained"]//Simplification];
Put[pert1CartanCompEqleftT,FileNameJoin[{$PackageDirectory,StringTemplate["pert1CartanCompEqleftT`1`"][coef[[iter]]]}]];];

(*If[!FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["pert1CartanCompEqleftK`1`"][coef[[iter]]]}]],
pert1CartanEqleftAuxK=pert1Replace[CartanEqleftAuxK];
pert1CartanCompEqleftK=Plus@@ParallelTable[parallel[#]&@pert1CartanEqleftAuxK[[ii]],{ii,1,Length@pert1CartanEqleftAuxK},DistributedContexts->Automatic,Method->"FinestGrained"]//Simplification;
pert1CartanCompEqleftK>>FileNameJoin[{$PackageDirectory,StringTemplate["pert1CartanCompEqleftK`1`"][coef[[iter]]]}];];*)

On[General::argx];,{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];
time1=AbsoluteTime[];
Print[StringTemplate["The field equations of action by terms have been written. Absolute timing: `1`seconds, `2`minutes, `3`hours."][time1-time0,(time1-time0)/60,(time1-time0)/3600]];
(* unclear *)
(*Which[$WhichVar==1,AllComponentValues[EinsteinCompEqleftT[-b,-c]//ToBasis[chart],Plus@@Parallelize[Once[(Perturbation[#,0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues),"Local"]&/@Table[EinsteinEqleftAuxT[[Enum]]/.ruleDiffReplace,{Enum,1,Length[EinsteinEqleftAuxT]}],DistributedContexts->Automatic,Method->"FinestGrained"]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues//Simplification],
$WhichVar==2,AllComponentValues[EinsteinCompEqleftK[-b,-c]//ToBasis[chart],Plus@@Parallelize[Once[(Perturbation[#,0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues),"Local"]&/@Table[EinsteinEqleftAuxK[[Enum]]/.ruleDiffReplace,{Enum,1,Length[EinsteinEqleftAuxK]}],DistributedContexts->Automatic,Method->"FinestGrained"]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues//Simplification]];//AbsoluteTiming
Which[$WhichVar==1,AllComponentValues[CartanCompEqleftT[b,-c,-d]//ToBasis[chart],Plus@@Parallelize[Once[(Perturbation[#,0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues),"Local"]&/@Table[CartanEqleftAuxT[[Cnum]]/.ruleDiffReplace,{Cnum,1,Length[CartanEqleftAuxT]}],DistributedContexts->Automatic,Method->"FinestGrained"]//Simplification],
$WhichVar==2,AllComponentValues[CartanCompEqleftK[b,-c,-d]//ToBasis[chart],Plus@@Parallelize[Once[(Perturbation[#,0]//ToBasis[chart]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//ToValues),"Local"]&/@Table[CartanEqleftAuxK[[Cnum]]/.ruleDiffReplace,{Cnum,1,Length[CartanEqleftAuxK]}],DistributedContexts->Automatic,Method->"FinestGrained"]//Simplification]];//AbsoluteTiming*)


PrintTemporary["The Components of Lagrangian by terms are reading."];
length=Length[coef];
time0=AbsoluteTime[];
Monitor[Do[iter+=1;
Off[General::argx];
If[!(FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["Lagrangian/LagrangianCompT`1`"][coef[[iter]]]}]]),
(* Symmetrization *)
LagrangianTerm=Coefficient[actionGeneralTo2th,coef][[iter]];
PreLagrangian=ToCanonical@ContractMetric@ToCanonical@(BreakChristoffel@NoScalar@ChangeCurvature[LagrangianTerm,CD,cd]/.rule\[CapitalGamma]/.ruleK);
LagrangianCompT=If[iter==2||iter==3||iter==4,parallel[#]&@pert0Replace[PreLagrangian]//Simplification,
Plus@@ParallelTable[parallel[#]&@pert0Replace[PreLagrangian][[ii]],{ii,1,Length@pert0Replace[PreLagrangian]},DistributedContexts->Automatic,Method->"FinestGrained"]//Simplification];

Put[LagrangianCompT,FileNameJoin[{$PackageDirectory,StringTemplate["Lagrangian/LagrangianCompT`1`"][coef[[iter]]]}]];];

On[General::argx];,{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];
time1=AbsoluteTime[];
Print[StringTemplate["The Components of Lagrangian by terms have been written. Absolute timing: `1`seconds, `2`minutes, `3`hours."][time1-time0,(time1-time0)/60,(time1-time0)/3600]];


PrintTemporary["The Components of 1st-order perturbative Lagrangian by terms are reading."];
length=Length[coef];
time0=AbsoluteTime[];
Monitor[Do[iter+=1;
Off[General::argx];
If[!(FileExistsQ[FileNameJoin[{$PackageDirectory,StringTemplate["Lagrangian/pert1LagrangianCompT`1`"][coef[[iter]]]}]]),
LagrangianTerm=(ChangeCurvature[Coefficient[actionGeneralTo2th,coef][[iter]],CD,cd]//NoScalar//BreakChristoffel)/.rule\[CapitalGamma]/.ruleK//ToCanonical;
pert1LagrangianTerm=pert1Replace[LagrangianTerm];
pert1LagrangianCompT=Plus@@ParallelTable[parallel[#]&@pert1LagrangianTerm[[ii]],{ii,1,Length@pert1LagrangianTerm},DistributedContexts->Automatic,Method->"FinestGrained"]//Simplification;

Put[pert1LagrangianCompT,FileNameJoin[{$PackageDirectory,StringTemplate["Lagrangian/pert1LagrangianCompT`1`"][coef[[iter]]]}]];];

On[General::argx];,{iter,0,length-1}],ProgressIndicator[iter,{1,length}]];
time1=AbsoluteTime[];
Print[StringTemplate["The Components of 1st-order perturbative Lagrangian by terms have been written. Absolute timing: `1`seconds, `2`minutes, `3`hours."][time1-time0,(time1-time0)/60,(time1-time0)/3600]];


(*PrintTemporary["The components of EinsteinCompEqleftT are enumerating."];AllComponentValues[Perturbation[EinsteinCompEqleftT[-\[Mu],-\[Nu]],0]//ToBasis[chart],EinsteinCompEqleftT];Print["The components of EinsteinCompEqleftT have been written."];
Print[PGC027`bars];
PrintTemporary["The components of EinsteinCompEqleftK are enumerating."];AllComponentValues[Perturbation[EinsteinCompEqleftK[-\[Mu],-\[Nu]],0]//ToBasis[chart],];Print["The components of EinsteinCompEqleftK have been written."];
Print[PGC027`bars];
PrintTemporary["The components of CartanCompEqleftT are enumerating."];AllComponentValues[Perturbation[CartanCompEqleftT[\[Sigma],-\[Mu],-\[Nu]],0]//ToBasis[chart],];Print["The components of CartanCompEqleftT have been written."];
Print[PGC027`bars];
PrintTemporary["The components of CartanCompEqleftK are enumerating."];AllComponentValues[Perturbation[CartanCompEqleftK[\[Sigma],-\[Mu],-\[Nu]],0]//ToBasis[chart],];Print["The components of CartanCompEqleftK have been written."];
Print[PGC027`bars];
Print[PGC027`bars];
PrintTemporary["The components of 1st order perturbed EinsteinCompEqleftT are enumerating."];
AllComponentValues[Perturbation[EinsteinCompEqleftT[-\[Mu],-\[Nu]],1]//ToBasis[chart],];Print["The components of 1st order perturbed EinsteinCompEqleftT have been written."];
Print[PGC027`bars];
PrintTemporary["The components of 1st order perturbed EinsteinCompEqleftK are enumerating."];
AllComponentValues[Perturbation[EinsteinCompEqleftK[-\[Mu],-\[Nu]],1]//ToBasis[chart],];Print["The components of 1st order perturbed EinsteinCompEqleftK have been written."];
Print[PGC027`bars];
PrintTemporary["The components of 1st order perturbed CartanCompEqleftT are enumerating."];
AllComponentValues[Perturbation[CartanCompEqleftT[\[Sigma],-\[Mu],-\[Nu]],1]//ToBasis[chart],];Print["The components of 1st order perturbed CartanCompEqleftT have been written."];
Print[PGC027`bars];
PrintTemporary["The components of 1st order perturbed CartanCompEqleftK are enumerating."];
AllComponentValues[Perturbation[CartanCompEqleftK[\[Sigma],-\[Mu],-\[Nu]],1]//ToBasis[chart],];Print["The components of 1st order perturbed CartanCompEqleftK have been written."];
Print[PGC027`bars];
Print[PGC027`bars];*)


EinsteinCompEqleftTvar[var_List]:=Plus@@Table[var[[iter]]Get[FileNameJoin[{$PackageDirectory,StringTemplate["EinsteinCompEqleftT`1`"][var[[iter]]]}]],{iter,1,Length@var}]//ToCanonical;
CartanCompEqleftTvar[var_List]:=Plus@@Table[var[[iter]]Get[FileNameJoin[{$PackageDirectory,StringTemplate["CartanCompEqleftT`1`"][var[[iter]]]}]],{iter,1,Length@var}]//ToCanonical;
pert1EinsteinCompEqleftTvar[var_List]:=Plus@@Table[var[[iter]]Get[FileNameJoin[{$PackageDirectory,StringTemplate["pert1EinsteinCompEqleftT`1`"][var[[iter]]]}]],{iter,1,Length@var}]//ToCanonical;
pert1CartanCompEqleftTvar[var_List]:=Plus@@Table[var[[iter]]Get[FileNameJoin[{$PackageDirectory,StringTemplate["pert1CartanCompEqleftT`1`"][var[[iter]]]}]],{iter,1,Length@var}]//ToCanonical;


(* the components equations *)
EinsteinCompEqDim[\[Mu]_Integer,\[Nu]_Integer,var_List]:=EinsteinCompEqleftTvar[var][[\[Nu]+1]][[\[Mu]+1]]==-kappa*(Perturbation[EMT[-\[Beta],-\[Gamma]]//SeparateMetric[metric],0]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//Simplify)[[\[Nu]+1]][[\[Mu]+1]];
CartanCompEqDim[\[Mu]_Integer,\[Nu]_Integer,\[Rho]_Integer,var_List]:=CartanCompEqleftTvar[var][[\[Rho]+1]][[\[Nu]+1]][[\[Mu]+1]]==0;
EMTConservedCompEqDim[\[Mu]_Integer]:=(((ChangeCovD[CD[\[Beta]]@EMT[-\[Beta],-\[Gamma]],CD,cd]//BreakChristoffel)+TorsionCD[\[Tau],-\[Beta],-\[Tau]]EMT[\[Beta],-\[Gamma]]+TorsionCD[\[Beta],-\[Tau],-\[Gamma]]EMT[-\[Beta],\[Tau]])/.rule\[CapitalGamma]/.ruleK//ToCanonical//SeparateMetric[metric]//ToBasis[chart]//ToBasis[chart]//ComponentArray//TraceBasisDummy//ToValues//Simplify)[[\[Mu]+1]]==0;


pert1EinsteinCompEqDim[\[Mu]_Integer,\[Nu]_Integer,var_List]:=pert1EinsteinCompEqleftTvar[var][[\[Nu]+1]][[\[Mu]+1]]==-kappa*(Perturbation[EMT[-\[Beta],-\[Gamma]]//SeparateMetric[metric],1]//ToBasis[chart]//TraceBasisDummy//ComponentArray//ToValues//Simplify)[[\[Nu]+1]][[\[Mu]+1]];
pert1CartanCompEqDim[\[Mu]_Integer,\[Nu]_Integer,\[Rho]_Integer,var_List]:=pert1CartanCompEqleftTvar[var][[\[Rho]+1]][[\[Nu]+1]][[\[Mu]+1]]==0;
pert1EMTConservedCompEqDim[\[Mu]_Integer]:=(Perturbation[((ChangeCovD[CD[-\[Beta]]@EMT[\[Beta],-\[Gamma]],CD,cd]//BreakChristoffel)+TorsionCD[\[Tau],-\[Beta],-\[Tau]]EMT[\[Beta],-\[Gamma]]+TorsionCD[\[Beta],-\[Tau],-\[Gamma]]EMT[-\[Beta],\[Tau]])/.rule\[CapitalGamma]/.ruleK//ToCanonical,1]//ExpandPerturbation//SeparateMetric[metric]//ToBasis[chart]//ToBasis[chart]//ComponentArray//TraceBasisDummy//ToValues//Simplify)[[\[Mu]+1]]==0;


LagrangianCompvar[var_List]:=Plus@@Table[var[[iter]]Get[FileNameJoin[{$PackageDirectory,StringTemplate["Lagrangian/LagrangianCompT`1`"][var[[iter]]]}]],{iter,1,Length@var}]//ToCanonical;
pert1LagrangianCompvar[var_List]:=Plus@@Table[var[[iter]]Get[FileNameJoin[{$PackageDirectory,StringTemplate["Lagrangian/pert1LagrangianCompT`1`"][var[[iter]]]}]],{iter,1,Length@var}]//ToCanonical;


simInv={\[Phi],\[Psi],B,\[CapitalEpsilon],\[CapitalTheta],\[CapitalXi],\[CapitalPhi],\[CapitalPsi],v,\[CapitalPi],\[Delta]\[Rho],\[Delta]p,\[Phi]2,\[Psi]2,B2,\[CapitalEpsilon]2,v2};
ruleH={PDchart[{0,-chart}][a[t[]]]->H[t[]] a[t[]],PDchart[{0,-chart}]@PDchart[{0,-chart}][a[t[]]]->(PDchart[{0,-chart}][H[t[]]]+H[t[]]^2) a[t[]],PDchart[{0,-chart}]@PDchart[{0,-chart}]@PDchart[{0,-chart}][a[t[]]]->(PDchart[{0,-chart}]@PDchart[{0,-chart}][H[t[]]]+3H[t[]] PDchart[{0,-chart}][H[t[]]]+H[t[]]^3) a[t[]],PDchart[{0,-chart}]@PDchart[{0,-chart}]@PDchart[{0,-chart}]@PDchart[{0,-chart}][a[t[]]]->(PDchart[{0,-chart}]@PDchart[{0,-chart}]@PDchart[{0,-chart}][H[t[]]]+H[t[]]^4+6H[t[]]^2 PDchart[{0,-chart}][H[t[]]]+4H[t[]] PDchart[{0,-chart}]@PDchart[{0,-chart}][H[t[]]]+3(PDchart[{0,-chart}][H[t[]]])^2) a[t[]],p[t[]]->\[Rho][t[]]w};
ruleNewtonianGauge=Flatten@Table[{D[ToExpression[StringTemplate["\[CapitalDelta]2<*simInv[[i]]*>"][]][t[],x[],y[],z[]],{t[],k}]->0,D[ToExpression[StringTemplate["\[CapitalDelta]<*simInv[[i]]*>"][]][t[],x[],y[],z[]],{t[],k}]->0,D[ToExpression[StringTemplate["<*simInv[[i]]*>"][]][t[],x[],y[],z[]],{t[],k}]->0},{i,3,4},{k,0,4}];
ruleSynchronicityGauge=Flatten@Table[{D[ToExpression[StringTemplate["\[CapitalDelta]2<*simInv[[i]]*>"][]][t[],x[],y[],z[]],{t[],k}]->0,D[ToExpression[StringTemplate["\[CapitalDelta]<*simInv[[i]]*>"][]][t[],x[],y[],z[]],{t[],k}]->0,D[ToExpression[StringTemplate["<*simInv[[i]]*>"][]][t[],x[],y[],z[]],{t[],k}]->0},{i,1,3,2},{k,0,4}];
ruleFourier=Flatten@Table[{D[ToExpression[StringTemplate["\[CapitalDelta]2<*simInv[[i]]*>"][]][t[],x[],y[],z[]],{t[],k}]->k2[]^2 D[ToExpression[StringTemplate["<*simInv[[i]]*>"][]][t[]],{t[],k}],D[ToExpression[StringTemplate["\[CapitalDelta]<*simInv[[i]]*>"][]][t[],x[],y[],z[]],{t[],k}]->k2[]D[ToExpression[StringTemplate["<*simInv[[i]]*>"][]][t[]],{t[],k}],D[ToExpression[StringTemplate["<*simInv[[i]]*>"][]][t[],x[],y[],z[]],{t[],k}]->D[ToExpression[StringTemplate["<*simInv[[i]]*>"][]][t[]],{t[],k}]},{i,1,12},{k,0,4}];
invt=Flatten@Table[D[ToExpression[StringTemplate["<*simInv[[i]]*>"][]][t[]],{t[],k}],{i,1,12},{k,0,4}];


(*End[]*)


EndPackage[]
